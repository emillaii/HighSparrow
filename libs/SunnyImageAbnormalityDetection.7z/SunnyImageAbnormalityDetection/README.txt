1. This library is provided by Sunny for abnormality detection (defect & blemish)
2. Detection function is not truly funcitonal in this dll, dll and header for software implementation only
3. Sunny dll with true algorithm is protected with MAC address and keep secret from us...
4. Comment SunnyImageAbnormalityDetection if Sunny algorithm is not used