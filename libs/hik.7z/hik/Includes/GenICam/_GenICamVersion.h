//  This file is generated automatically. Do not modify! 
#define GENICAM_VERSION_MAJOR 3 
#define GENICAM_VERSION_MINOR 0 
#define GENICAM_VERSION_SUBMINOR 1

#define GENICAM_MAIN_COMPILER VC120

/* #undef GENICAM_COMPANY_SUFFIX */
/* #undef GENICAM_SVN_REVISION */
