#ifndef PAVA_H
#define PAVA_H

void jbk_pava(double *x, int n);

#endif
