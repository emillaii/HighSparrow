#ifndef SFR_H
#define SFR_H

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include "sfr_entry.h"
#include <image_util.h>
#include <sparrowcore_global.h>

class SPARROWCORESHARED_EXPORT sfr
{
public:
    enum EdgeFilter {
        NO_FILTER,
        VERTICAL_ONLY,
        HORIZONTAL_ONLY
    };

    typedef std::vector<std::tuple<int, int, cv::Mat> > searchROI_func_type(const cv::Mat &inImage,
                                                                  unsigned int &centerROIIndex,
                                                                  unsigned int & ulROIIndex,
                                                                  unsigned int & urROIIndex,
                                                                  unsigned int & llROIIndex,
                                                                  unsigned int & lrROIIndex);
    static void sfr_calculation(std::vector<std::tuple<double, double, vector<double>>> &v_sfr, cv::Mat& cvimg, int freq_factor = 1,  EdgeFilter filter = NO_FILTER);
    static vector<Sfr_entry> calculateSfr(double currZPos, cv::Mat& cvimg, int freq_factor = 1, EdgeFilter filter = NO_FILTER);
    static vector<Sfr_entry> calculateSfrWithRoiBreakdown(double currZPos, cv::Mat& cvimg, bool isDebug, searchROI_func_type searchROI = image_util::searchROI);
private:
    sfr() {}
};

#endif // SFR_H
