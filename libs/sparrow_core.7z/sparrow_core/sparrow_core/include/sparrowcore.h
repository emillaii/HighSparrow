#ifndef SPARROWCORE_H
#define SPARROWCORE_H

#include "sparrowcore_global.h"

class SPARROWCORESHARED_EXPORT SparrowCore
{

public:
    SparrowCore();
};

#endif // SPARROWCORE_H
